
// for store directory
document.addEventListener("DOMContentLoaded", function() {
  // Select all buttons and popup text containers
  const buttons = document.querySelectorAll('.store button');
  const popupTexts = document.querySelectorAll('.popup-text');

  // Add click event listeners to each button
  buttons.forEach((button, index) => {
    button.addEventListener('click', function() {
      // Hide all popup texts first
      popupTexts.forEach(popupText => {
        popupText.style.display = 'none';
      });

      // Show the corresponding popup text based on index
      popupTexts[index].style.display = 'block';
    });
  });
});

//for menu
function setupFilterFunctionality() {
  const filterButtons = document.querySelectorAll('.list');
  const items = document.querySelectorAll('.itembox');

  filterButtons.forEach(button => {
      button.addEventListener('click', function() {
          // Remove active class from all buttons
          filterButtons.forEach(btn => btn.classList.remove('active'));
          // Add active class to the clicked button
          this.classList.add('active');

          const filterValue = this.getAttribute('data-filter');

          items.forEach(item => {
              const itemCategory = item.getAttribute('data-item');
              // If data-item matches filterValue or filterValue is 'all', display item; otherwise hide it
              if (filterValue === 'all' || filterValue === itemCategory) {
                  item.style.display = 'block';
              } else {
                  item.style.display = 'none';
              }
          });
      });
  });
}

// Event listener for DOMContentLoaded to call setupFilterFunctionality
document.addEventListener("DOMContentLoaded", function () {
  setupFilterFunctionality();
});